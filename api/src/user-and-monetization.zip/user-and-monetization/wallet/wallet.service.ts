import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { Wallet, WalletDocument } from './schemas/wallet.schema';

@Injectable()
export class WalletService {
  constructor(@InjectModel(Wallet.name) private walletModel: Model<WalletDocument>) {}

  async createWallet(userId: Types.ObjectId): Promise<WalletDocument> {
    const wallet = new this.walletModel({ userId });
    return wallet.save();
  }

  async getBalance(userId: Types.ObjectId): Promise<number> {
    const wallet = await this.walletModel.findOne({ userId });
    if (!wallet) throw new Error('Wallet not found');
    return wallet.balance;
  }

async addBalance(userId: Types.ObjectId, amount: number): Promise<WalletDocument> {
  const wallet = await this.walletModel.findOneAndUpdate(
    { userId },
    { $inc: { balance: amount } },
    { new: true, upsert: true },
  );
  if (!wallet) throw new Error('Wallet not found');
  return wallet;
}

async deductBalance(userId: Types.ObjectId, amount: number): Promise<WalletDocument> {
  const wallet = await this.walletModel.findOneAndUpdate(
    { userId },
    { $inc: { balance: -amount } },
    { new: true },
  );
  if (!wallet) throw new Error('Wallet not found');
  return wallet;
}

}
