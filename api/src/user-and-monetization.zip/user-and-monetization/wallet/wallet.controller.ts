import { Controller, Get, Param } from '@nestjs/common';
import { WalletService } from './wallet.service';
import { Types } from 'mongoose';

@Controller('wallet')
export class WalletController {
  constructor(private readonly walletService: WalletService) {}

  @Get(':userId')
  async getBalance(@Param('userId') userId: string) {
    return this.walletService.getBalance(new Types.ObjectId(userId));
  }
}
