import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { PesapalService } from './pesapal.service';
import { PesapalController } from './pesapal.controller';
import { PesapalOrder, PesapalOrderSchema } from './pesapal.schema';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: PesapalOrder.name, schema: PesapalOrderSchema }]),
    EventEmitterModule.forRoot(), // ✅ ADD EVENT EMITTER
  ],
  controllers: [PesapalController],
  providers: [PesapalService],
  exports: [PesapalService],
})
export class PesapalModule {}