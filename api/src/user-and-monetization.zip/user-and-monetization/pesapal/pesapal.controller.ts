import { Controller, Post, Get, Body, Param, HttpCode, Logger, Query } from '@nestjs/common';
import { PesapalService } from './pesapal.service';
import { CreateOrderDto, PesapalCallbackDto } from './pesapal.dto';

@Controller('pesapal')
export class PesapalController {
  private readonly logger = new Logger(PesapalController.name);

  constructor(private readonly pesapalService: PesapalService) {}

  /**
   * Create payment order
   * Called from frontend Subscribe.tsx
   */
  @Post('create-order')
  @HttpCode(200)
  async createOrder(@Body() dto: CreateOrderDto) {
    this.logger.log('➡️ Incoming order body:', JSON.stringify(dto));
    this.logger.log('Token available:', !!dto.userId);

    try {
      const result = await this.pesapalService.createOrder(dto);

      return {
        success: true,
        redirectUrl: result.redirectUrl,
        trackingId: result.trackingId,
        merchantReference: result.merchantReference,
        planName: dto.planName,
        userId: dto.userId,
      };
    } catch (error: any) {
      this.logger.error('❌ Error creating order:', error.message);
      throw error;
    }
  }

  /**
   * Pesapal callback - GET method
   * Called by Pesapal redirect
   */
  @Get('callback')
  async handleCallbackGet(@Query() query: any) {
    this.logger.log('📥 Pesapal GET callback query:', JSON.stringify(query));

    const orderTrackingId = query.OrderTrackingId || query.orderTrackingId;
    if (!orderTrackingId) {
      return { success: false, message: 'Missing OrderTrackingId in query' };
    }

    try {
      await this.pesapalService.handlePaymentCallback(orderTrackingId);
      return { success: true, message: 'Callback processed' };
    } catch (error: any) {
      this.logger.error('Error processing callback:', error.message);
      return { success: false, message: error.message };
    }
  }

  /**
   * Pesapal callback - POST method (IPN)
   * Called by Pesapal IPN notification
   */
  @Post('callback')
  @HttpCode(200)
  async handleCallbackPost(@Body() body: any) {
    this.logger.log('📥 Pesapal POST callback body:', JSON.stringify(body));

    const orderTrackingId = body.OrderTrackingId || body.orderTrackingId;
    if (!orderTrackingId) {
      return { success: false, message: 'Missing OrderTrackingId in body' };
    }

    try {
      await this.pesapalService.handlePaymentCallback(orderTrackingId);
      return { success: true, message: 'IPN processed' };
    } catch (error: any) {
      this.logger.error('Error processing IPN:', error.message);
      return { success: false, message: error.message };
    }
  }

  /**
   * Get transaction status from Pesapal
   */
  @Get('order/:trackingId/status')
  async getOrderStatus(@Param('trackingId') trackingId: string) {
    this.logger.log(`🔍 Checking status for trackingId: ${trackingId}`);

    try {
      const status = await this.pesapalService.getTransactionStatus(trackingId);
      return {
        success: true,
        status: status.payment_status || status.status || 'UNKNOWN',
        raw: status,
      };
    } catch (error: any) {
      this.logger.error('Error getting status:', error.message);
      return {
        success: false,
        status: 'ERROR',
        message: error.message,
      };
    }
  }

  /**
   * Verify payment and activate subscription
   * Called from frontend PaymentSuccess.tsx
   */
  @Post('verify')
  @HttpCode(200)
  async verifyPayment(
    @Body()
    body: {
      orderTrackingId: string;
      userId: string;
      planType: 'monthly' | 'quarterly' | 'half_year' | 'yearly';
    },
  ) {
    const { orderTrackingId, userId, planType } = body;

    if (!orderTrackingId || !userId) {
      return {
        success: false,
        message: 'Missing orderTrackingId or userId',
      };
    }

    this.logger.log(`✅ Verifying payment for orderTrackingId: ${orderTrackingId}`);

    try {
      const status = await this.pesapalService.getTransactionStatus(orderTrackingId);
      this.logger.log('Pesapal status response:', JSON.stringify(status));

      const paymentStatus =
        status?.payment_status_description ||
        status?.payment_status ||
        status?.status ||
        status?.paymentStatus;

      const normalizedStatus =
        (paymentStatus || '').toUpperCase();

      const isCompleted = ['COMPLETED', 'PAID', 'SUCCESS'].includes(normalizedStatus);

      if (isCompleted) {
        this.logger.log(
          `✅ Payment verified as COMPLETED for order: ${orderTrackingId}`,
        );

        // ✅ TODO: Activate subscription in your database
        // This is where you'd call a subscription service to activate the user's subscription
        // await this.subscriptionService.activateSubscription(userId, planType, amount);

        return {
          success: true,
          status: normalizedStatus,
          message: 'Payment verified and subscription activated',
          orderTrackingId,
          userId,
          planType,
        };
      } else if (normalizedStatus === 'PENDING') {
        return {
          success: false,
          status: 'PENDING',
          message: 'Payment is still pending',
          orderTrackingId,
        };
      } else {
        return {
          success: false,
          status: normalizedStatus,
          message: 'Payment failed or invalid',
          orderTrackingId,
        };
      }
    } catch (error: any) {
      this.logger.error(`❌ Error verifying payment: ${error.message}`);
      return {
        success: false,
        status: 'ERROR',
        message: 'Error verifying payment',
        error: error.message,
      };
    }
  }

  /**
   * Get user's orders
   */
  @Get('orders/:userId')
  async getUserOrders(@Param('userId') userId: string) {
    this.logger.log(`📋 Fetching orders for user: ${userId}`);

    try {
      const orders = await this.pesapalService.getUserOrders(userId);
      return {
        success: true,
        orders,
      };
    } catch (error: any) {
      this.logger.error('Error fetching orders:', error.message);
      return {
        success: false,
        message: error.message,
      };
    }
  }

  /**
   * Get order by ID
   */
  @Get('order/:orderId')
  async getOrderById(@Param('orderId') orderId: string) {
    this.logger.log(`📦 Fetching order: ${orderId}`);

    try {
      const order = await this.pesapalService.getOrderById(orderId);
      return {
        success: true,
        order,
      };
    } catch (error: any) {
      this.logger.error('Error fetching order:', error.message);
      return {
        success: false,
        message: error.message,
      };
    }
  }
}