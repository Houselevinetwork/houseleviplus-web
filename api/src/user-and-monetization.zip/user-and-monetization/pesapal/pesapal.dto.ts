// ============================================
// 1. pesapal.dto.ts - Data Transfer Objects
// ============================================
export class CreateOrderDto {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  userId: string;
  planName: string;
  planType: 'monthly' | 'quarterly' | 'half_year' | 'yearly';
  amount: number;
  description: string;
  callbackUrl: string;
}

export class PesapalCallbackDto {
  OrderMerchantReference: string;
  OrderTrackingId: string;
  OrderStatus: 'COMPLETED' | 'FAILED' | 'PENDING';
  OrderNotificationType: string;
}
