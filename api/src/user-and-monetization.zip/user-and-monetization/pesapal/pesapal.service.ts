import { Injectable, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Document } from 'mongoose';
import axios from 'axios';
import { CreateOrderDto, PesapalCallbackDto } from './pesapal.dto';
import { PesapalOrder } from './pesapal.schema';
import { IPesapalAuthToken } from './pesapal.interface';
import { EventEmitter2 } from '@nestjs/event-emitter';

@Injectable()
export class PesapalService {
  private readonly logger = new Logger(PesapalService.name);
  private pesapalAuthToken: IPesapalAuthToken | null = null;

  private readonly PESAPAL_CONSUMER_KEY = process.env.PESAPAL_CONSUMER_KEY;
  private readonly PESAPAL_CONSUMER_SECRET = process.env.PESAPAL_CONSUMER_SECRET;
  // 🔴 LIVE ENVIRONMENT - Using production Pesapal
  private readonly PESAPAL_BASE_URL = 'https://pay.pesapal.com/v3/api';
  private readonly PESAPAL_MERCHANT_EMAIL = process.env.PESAPAL_MERCHANT_EMAIL;
  private readonly PESAPAL_CALLBACK_URL = process.env.PESAPAL_CALLBACK_URL;
  private ipnId: string = '';

  constructor(
    @InjectModel(PesapalOrder.name) private pesapalOrderModel: Model<PesapalOrder>,
    private eventEmitter: EventEmitter2,
  ) {
    this.validateCredentials();
  }

  /**
   * 🔴 VALIDATE CREDENTIALS ON SERVICE INIT
   */
  private validateCredentials(): void {
    this.logger.log('🌍 Environment: PRODUCTION (LIVE KEYS)');
    this.logger.log(`🔌 Base URL: ${this.PESAPAL_BASE_URL}`);
    this.logger.warn('⚠️  WARNING: Using LIVE Pesapal keys - Real money transactions will occur!');

    if (!this.PESAPAL_CONSUMER_KEY) {
      this.logger.error('❌ PESAPAL_CONSUMER_KEY is missing in environment variables!');
      console.error('❌ ERROR: PESAPAL_CONSUMER_KEY not found in .env');
    } else {
      this.logger.log(`✅ PESAPAL_CONSUMER_KEY loaded (${this.PESAPAL_CONSUMER_KEY.substring(0, 5)}...)`);
    }

    if (!this.PESAPAL_CONSUMER_SECRET) {
      this.logger.error('❌ PESAPAL_CONSUMER_SECRET is missing in environment variables!');
      console.error('❌ ERROR: PESAPAL_CONSUMER_SECRET not found in .env');
    } else {
      this.logger.log(`✅ PESAPAL_CONSUMER_SECRET loaded (${this.PESAPAL_CONSUMER_SECRET.substring(0, 5)}...)`);
    }

    if (!this.PESAPAL_CALLBACK_URL) {
      this.logger.warn('⚠️  PESAPAL_CALLBACK_URL not set - IPN notifications may fail');
    } else {
      this.logger.log(`✅ PESAPAL_CALLBACK_URL: ${this.PESAPAL_CALLBACK_URL}`);
    }

    if (this.PESAPAL_CONSUMER_KEY && this.PESAPAL_CONSUMER_SECRET) {
      this.logger.log('✅ Pesapal credentials validated successfully');
      this.logger.warn('🚀 LIVE PAYMENT PROCESSING ENABLED');
    }
  }

  /**
   * Get Pesapal authentication token
   */
  private async getAuthToken(): Promise<string> {
    try {
      // Check if token is still valid
      if (this.pesapalAuthToken && this.pesapalAuthToken.expiresAt > Date.now()) {
        this.logger.log('Using cached auth token');
        return this.pesapalAuthToken.token;
      }

      this.logger.log(`Requesting auth token from: ${this.PESAPAL_BASE_URL}/Auth/RequestToken`);

      const response = await axios.post(
        `${this.PESAPAL_BASE_URL}/Auth/RequestToken`,
        {
          consumer_key: this.PESAPAL_CONSUMER_KEY,
          consumer_secret: this.PESAPAL_CONSUMER_SECRET,
        },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        },
      );

      const token = response?.data?.token;
      if (!token) {
        throw new Error('Pesapal auth response invalid - no token returned');
      }

      this.pesapalAuthToken = {
        token,
        expiresIn: response.data?.expiresIn || 3600,
        expiresAt: Date.now() + (response.data?.expiresIn || 3600) * 1000,
      };

      this.logger.log('✅ Pesapal auth token obtained successfully');
      return this.pesapalAuthToken.token;
    } catch (error: any) {
      this.logger.error('❌ Failed to get Pesapal auth token:');
      this.logger.error('Status:', error.response?.status);
      this.logger.error('Data:', error.response?.data);
      this.logger.error('Message:', error.message);

      // Specific 401 help for LIVE keys
      if (error.response?.status === 401) {
        this.logger.error('');
        this.logger.error('🔴 401 UNAUTHORIZED - Pesapal rejected your credentials');
        this.logger.error('✅ FIX FOR LIVE KEYS:');
        this.logger.error('   1. Log in to https://pesapal.com (LIVE - not sandbox)');
        this.logger.error('   2. Go to Settings → API Settings');
        this.logger.error('   3. Copy your LIVE Consumer Key and Consumer Secret');
        this.logger.error('   4. Update .env with LIVE credentials (not sandbox)');
        this.logger.error('   5. Make sure PESAPAL_CONSUMER_KEY is correct');
        this.logger.error('   6. Make sure PESAPAL_CONSUMER_SECRET is correct');
        this.logger.error('   7. Restart the server');
        this.logger.error('');
      }

      throw new HttpException(
        `Failed to authenticate with Pesapal: ${error.response?.data?.message || error.message}`,
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Register IPN dynamically or use existing
   */
  private async ensureIPNRegistered(): Promise<string> {
    if (this.ipnId) {
      this.logger.log('Using cached IPN ID');
      return this.ipnId;
    }

    if (!this.PESAPAL_CALLBACK_URL) {
      throw new HttpException('Callback URL required', HttpStatus.BAD_REQUEST);
    }

    try {
      const token = await this.getAuthToken();
      this.logger.log('📍 Registering IPN with URL:', this.PESAPAL_CALLBACK_URL);

      const response = await axios.post(
        `${this.PESAPAL_BASE_URL}/URLSetup/RegisterIPN`,
        {
          url: this.PESAPAL_CALLBACK_URL,
          ipn_notification_type: 'POST',
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        },
      );

      const ipnId = response?.data?.ipn_id;
      if (!ipnId) {
        throw new Error('Pesapal did not return an IPN ID');
      }

      this.ipnId = ipnId;
      this.logger.log('✅ IPN registered successfully:', ipnId);
      return ipnId;
    } catch (error: any) {
      this.logger.error('Failed to register IPN:');
      this.logger.error('Status:', error.response?.status);
      this.logger.error('Data:', error.response?.data);
      throw new HttpException(
        `Failed to register IPN: ${error.response?.data?.message || error.message}`,
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Create order and get payment URL
   */
  async createOrder(dto: CreateOrderDto): Promise<any> {
    try {
      // Validate input
      if (!dto.userId || !dto.email || !dto.phoneNumber || !dto.amount) {
        this.logger.error('Missing required fields');
        throw new HttpException(
          'Missing required fields: userId, email, phoneNumber, amount',
          HttpStatus.BAD_REQUEST,
        );
      }

      this.logger.log('➡️  Incoming order body:', JSON.stringify(dto));

      // Create order in database
      const order = await this.pesapalOrderModel.create({
        userId: dto.userId,
        planType: dto.planType,
        amount: dto.amount,
        customerEmail: dto.email,
        customerPhone: dto.phoneNumber,
        customerFirstName: dto.firstName,
        customerLastName: dto.lastName,
        orderStatus: 'PENDING',
      });

      this.logger.log(`Order created in DB: ${order._id}`);

      // Get Pesapal auth token
      this.logger.log('Token available:', !!this.PESAPAL_CONSUMER_KEY);
      const token = await this.getAuthToken();

      // Ensure IPN is registered
      const ipnId = await this.ensureIPNRegistered();

      // Prepare order payload
      const merchantReference = `SUB_${(order._id as any).toString()}`;

      const orderPayload = {
        id: merchantReference,
        currency: 'KES',
        amount: dto.amount,
        description: dto.description,
        notification_id: ipnId,
        callback_url: dto.callbackUrl,
        billing_address: {
          email_address: dto.email,
          phone_number: dto.phoneNumber,
          country_code: 'KE',
          first_name: dto.firstName,
          last_name: dto.lastName,
          line_1: 'Nairobi',
        },
      };

      this.logger.log('Sending order to Pesapal:', JSON.stringify(orderPayload));

      // Submit order to Pesapal
      const pesapalResponse = await axios.post(
        `${this.PESAPAL_BASE_URL}/Transactions/SubmitOrderRequest`,
        orderPayload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        },
      );

      // Extract response fields (Pesapal returns various field names)
      const orderTrackingId =
        pesapalResponse.data?.order_tracking_id ||
        pesapalResponse.data?.orderTrackingId ||
        pesapalResponse.data?.order_id;
      const redirectUrl =
        pesapalResponse.data?.redirect_url || pesapalResponse.data?.redirectUrl;

      if (!orderTrackingId || !redirectUrl) {
        this.logger.error('Invalid Pesapal response:', pesapalResponse.data);
        throw new Error('Pesapal did not return a valid order response');
      }

      // Save Pesapal tracking info
      order.pesapalOrderTrackingId = orderTrackingId;
      order.pesapalOrderMerchantRef = merchantReference;
      await order.save();

      this.logger.log(`✅ Pesapal order created: ${orderTrackingId}`);

      return {
        success: true,
        redirectUrl,
        trackingId: orderTrackingId,
        merchantReference,
      };
    } catch (error: any) {
      this.logger.error('❌ Error creating order:', error.message);
      throw new HttpException(
        error.response?.data?.message || error.message || 'Failed to create payment order',
        error.response?.status || HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Get transaction status from Pesapal
   */
  async getTransactionStatus(orderTrackingId: string): Promise<any> {
    try {
      const token = await this.getAuthToken();

      const response = await axios.get(
        `${this.PESAPAL_BASE_URL}/Transactions/GetTransactionStatus?orderTrackingId=${encodeURIComponent(orderTrackingId)}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );

      return response.data;
    } catch (error: any) {
      this.logger.error('Failed to get transaction status:', error.message);
      throw new HttpException(
        'Failed to retrieve transaction status',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Handle payment callback from Pesapal
   * 🔥 THIS IS THE KEY METHOD FOR SUBSCRIPTION ACTIVATION
   */
  async handlePaymentCallback(orderTrackingId: string): Promise<void> {
    try {
      const status = await this.getTransactionStatus(orderTrackingId);
      const paymentStatus =
        status?.payment_status_description ||
        status?.payment_status ||
        status?.status ||
        status?.paymentStatus;

      const completed =
        typeof paymentStatus === 'string' &&
        paymentStatus.toLowerCase().includes('completed');

      const order = await this.pesapalOrderModel.findOne({
        pesapalOrderTrackingId: orderTrackingId,
      });

      if (!order) {
        this.logger.warn(`Order not found for tracking ID: ${orderTrackingId}`);
        return;
      }

      if (completed) {
        order.orderStatus = 'COMPLETED';
        this.logger.log(`✅ Payment completed for order: ${order._id}`);

        // 🔥 EMIT EVENT FOR SUBSCRIPTION ACTIVATION
        // Other modules (SubscriptionService, UserService) will listen to this event
        this.eventEmitter.emit('payment.completed', {
          orderId: order._id,
          userId: order.userId,
          amount: order.amount,
          planType: order.planType,
          trackingId: orderTrackingId,
        });

        this.logger.log(`📢 Event emitted: payment.completed for order ${order._id}`);
      } else if (paymentStatus && paymentStatus.toLowerCase().includes('failed')) {
        order.orderStatus = 'FAILED';
        this.logger.log(`❌ Payment failed for order: ${order._id}`);

        // Emit payment failed event
        this.eventEmitter.emit('payment.failed', {
          orderId: order._id,
          userId: order.userId,
          trackingId: orderTrackingId,
        });
      } else {
        order.orderStatus = 'PENDING';
        this.logger.log(`⏳ Payment pending for order: ${order._id}`);
      }

      await order.save();
    } catch (error: any) {
      this.logger.error('Error handling payment callback:', error.message);
    }
  }

  /**
   * Get subscription status for user
   * GET /subscription/status?userId=xxx
   */
  async getSubscriptionStatus(userId: string): Promise<any> {
    try {
      const latestOrder = await this.pesapalOrderModel
        .findOne({ userId })
        .sort({ createdAt: -1 })
        .exec();

      if (!latestOrder) {
        return {
          status: 'no_subscription',
          isActive: false,
        };
      }

      const isActive = latestOrder.orderStatus === 'COMPLETED';

      return {
        status: isActive ? 'active' : 'inactive',
        isActive,
        order: {
          id: latestOrder._id,
          planType: latestOrder.planType,
          amount: latestOrder.amount,
          orderStatus: latestOrder.orderStatus,
          createdAt: latestOrder.createdAt,
        },
      };
    } catch (error: any) {
      this.logger.error('Error getting subscription status:', error.message);
      throw new HttpException(
        'Failed to get subscription status',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Get user's orders
   */
  async getUserOrders(userId: string): Promise<any[]> {
    return this.pesapalOrderModel.find({ userId }).sort({ createdAt: -1 }).exec();
  }

  /**
   * Get order by ID
   */
  async getOrderById(orderId: string): Promise<any> {
    const order = await this.pesapalOrderModel.findById(orderId).exec();
    if (!order) {
      throw new HttpException('Order not found', HttpStatus.NOT_FOUND);
    }
    return order;
  }
}