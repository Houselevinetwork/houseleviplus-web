import { Injectable, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import * as bcrypt from 'bcrypt';
import { Auth, AuthDocument } from './schemas/auth.schema';
import { WalletService } from '../wallet/wallet.service';
import { MailerService } from '@nestjs-modules/mailer';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    @InjectModel(Auth.name) private authModel: Model<AuthDocument>,
    private walletService: WalletService,
    private jwtService: JwtService,
    private mailerService: MailerService,
    private configService: ConfigService,
  ) {}

  /**
   * 📧 Generate email verification token
   */
  private generateVerificationToken(): string {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
  }

  /**
   * 📧 Send verification email with inline HTML
   */
  private async sendVerificationEmail(
    email: string,
    firstName: string,
    verificationToken: string,
  ): Promise<void> {
    try {
      const frontendUrl = this.configService.get<string>('FRONTEND_URL') || 'http://localhost:5173';
      // Updated to use /verify-email instead of /auth/verify
      const verificationUrl = `${frontendUrl}/verify-email?token=${verificationToken}`;
      const supportEmail = this.configService.get<string>('SUPPORT_EMAIL') || 'support@reelafrika.co.ke';

      const htmlContent = `
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Verify Your Email</title>
    <style>
      body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5; margin: 0; padding: 0; }
      .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
      .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; }
      .header h1 { margin: 0; font-size: 24px; }
      .content { padding: 30px; color: #333; }
      .content h2 { color: #333; font-size: 18px; margin-top: 0; }
      .button { display: inline-block; background-color: #667eea; color: white; padding: 12px 30px; border-radius: 5px; text-decoration: none; font-weight: bold; }
      .button:hover { background-color: #5568d3; }
      .footer { background-color: #f9f9f9; padding: 20px; text-align: center; font-size: 12px; color: #999; border-top: 1px solid #eee; }
      .button-container { text-align: center; margin: 20px 0; }
      .link-box { word-break: break-all; background-color: #f5f5f5; padding: 10px; border-radius: 5px; font-size: 12px; }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="header">
        <h1>The Reel Afrika</h1>
        <p>Welcome to our streaming platform</p>
      </div>

      <div class="content">
        <h2>Hi ${firstName},</h2>
        
        <p>Thank you for signing up! To complete your registration, please verify your email address by clicking the button below:</p>

        <div class="button-container">
          <a href="${verificationUrl}" class="button">
            Verify Email Address
          </a>
        </div>

        <p>Or copy and paste this link in your browser:</p>
        <div class="link-box">
          ${verificationUrl}
        </div>

        <p><strong>This link will expire in 24 hours.</strong></p>

        <p>If you didn't create an account, please ignore this email.</p>

        <p>Best regards,<br>The Reel Afrika Team</p>
      </div>

      <div class="footer">
        <p>If you have questions, contact us at <a href="mailto:${supportEmail}">${supportEmail}</a></p>
        <p>&copy; 2025 The Reel Afrika. All rights reserved.</p>
      </div>
    </div>
  </body>
</html>
      `;

      await this.mailerService.sendMail({
        to: email,
        subject: 'Verify your The Reel Afrika account',
        html: htmlContent,
      });

      this.logger.log(`✅ Verification email sent to ${email}`);
    } catch (error) {
      this.logger.error(`❌ Failed to send verification email to ${email}:`, error);
    }
  }

  /**
   * 📧 Send password reset email with inline HTML
   */
  private async sendPasswordResetEmail(
    email: string,
    firstName: string,
    resetToken: string,
  ): Promise<void> {
    try {
      const frontendUrl = this.configService.get<string>('FRONTEND_URL') || 'http://localhost:5173';
      const resetUrl = `${frontendUrl}/reset-password?token=${resetToken}`;
      const supportEmail = this.configService.get<string>('SUPPORT_EMAIL') || 'support@reelafrika.co.ke';

      const htmlContent = `
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Reset Your Password</title>
    <style>
      body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5; margin: 0; padding: 0; }
      .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
      .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; }
      .header h1 { margin: 0; font-size: 24px; }
      .content { padding: 30px; color: #333; }
      .content h2 { color: #333; font-size: 18px; margin-top: 0; }
      .button { display: inline-block; background-color: #667eea; color: white; padding: 12px 30px; border-radius: 5px; text-decoration: none; font-weight: bold; }
      .button:hover { background-color: #5568d3; }
      .warning { background-color: #fff3cd; border: 1px solid #ffc107; color: #856404; padding: 15px; border-radius: 5px; margin: 20px 0; }
      .footer { background-color: #f9f9f9; padding: 20px; text-align: center; font-size: 12px; color: #999; border-top: 1px solid #eee; }
      .button-container { text-align: center; margin: 20px 0; }
      .link-box { word-break: break-all; background-color: #f5f5f5; padding: 10px; border-radius: 5px; font-size: 12px; }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="header">
        <h1>The Reel Afrika</h1>
        <p>Password Reset Request</p>
      </div>

      <div class="content">
        <h2>Hi ${firstName},</h2>
        
        <p>We received a request to reset your password. Click the button below to set a new password:</p>

        <div class="button-container">
          <a href="${resetUrl}" class="button">
            Reset Password
          </a>
        </div>

        <p>Or copy and paste this link in your browser:</p>
        <div class="link-box">
          ${resetUrl}
        </div>

        <div class="warning">
          <strong>⚠️ This link will expire in 1 hour</strong>
        </div>

        <p>If you didn't request a password reset, please ignore this email or contact us immediately at <a href="mailto:${supportEmail}">${supportEmail}</a></p>

        <p>Best regards,<br>The Reel Afrika Team</p>
      </div>

      <div class="footer">
        <p>If you have questions, contact us at <a href="mailto:${supportEmail}">${supportEmail}</a></p>
        <p>&copy; 2025 The Reel Afrika. All rights reserved.</p>
      </div>
    </div>
  </body>
</html>
      `;

      await this.mailerService.sendMail({
        to: email,
        subject: 'Reset your The Reel Afrika password',
        html: htmlContent,
      });

      this.logger.log(`✅ Password reset email sent to ${email}`);
    } catch (error) {
      this.logger.error(`❌ Failed to send password reset email to ${email}:`, error);
      throw new HttpException(
        'Failed to send reset email',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * 📝 REGISTER - Create new user with email verification
   */
  async register(dto: {
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    password: string;
  }): Promise<{ token: string; user: any; subscription: any; message: string }> {
    try {
      // ✅ Check if user already exists
      const existingUser = await this.authModel.findOne({
        $or: [{ email: dto.email }, { phoneNumber: dto.phoneNumber }],
      });

      if (existingUser) {
        throw new HttpException(
          'User with this email or phone number already exists',
          HttpStatus.CONFLICT,
        );
      }

      // ✅ Hash password
      const hashedPassword = await bcrypt.hash(dto.password, 10);

      // ✅ Generate verification token
      const verificationToken = this.generateVerificationToken();
      const verificationTokenExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000);

      // ✅ Create user
      const user = new this.authModel({
        ...dto,
        password: hashedPassword,
        verificationToken,
        verificationTokenExpiry,
        emailVerified: false,
      });

      await user.save();
      this.logger.log(`✅ User registered: ${user.email}`);

      // ✅ Create wallet for user
      const userId = (user._id as Types.ObjectId);
      await this.walletService.createWallet(userId);
      this.logger.log(`✅ Wallet created for user: ${user._id}`);

      // ✅ Send verification email
      await this.sendVerificationEmail(
        user.email,
        user.firstName,
        verificationToken,
      );

      // ✅ Generate JWT token
      const token = this.jwtService.sign({
        sub: (user._id as Types.ObjectId).toString(),
        email: user.email,
      });

      // ✅ Get subscription info
      const subscription = await this.getSubscription(user._id as Types.ObjectId);

      return {
        token,
        user: {
          _id: user._id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          phoneNumber: user.phoneNumber,
          emailVerified: user.emailVerified,
        },
        subscription,
        message: 'Account created. Please check your email to verify your account.',
      };
    } catch (error: any) {
      this.logger.error(`❌ Registration error: ${error.message}`);
      throw error;
    }
  }

  /**
   * ✅ Verify email with token
   */
  async verifyEmail(token: string): Promise<{ success: boolean; message: string; user?: any }> {
    try {
      this.logger.log(`🔍 Looking up user with verification token: ${token.substring(0, 10)}...`);

      // Find user with this token that hasn't expired
      const user = await this.authModel.findOne({
        verificationToken: token,
        verificationTokenExpiry: { $gt: new Date() },
      });

      if (!user) {
        this.logger.error('❌ Invalid or expired verification token');
        throw new HttpException(
          'Invalid or expired verification token. Please request a new verification email.',
          HttpStatus.BAD_REQUEST,
        );
      }

      // Check if already verified
      if (user.emailVerified) {
        this.logger.log(`ℹ️  Email already verified for user: ${user.email}`);
        return {
          success: true,
          message: 'Email already verified! You can now log in.',
          user: {
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
          },
        };
      }

      // ✅ Mark email as verified
      user.emailVerified = true;
      user.verificationToken = undefined;
      user.verificationTokenExpiry = undefined;
      await user.save();

      this.logger.log(`✅ Email verified successfully for user: ${user.email}`);

      return {
        success: true,
        message: 'Email verified successfully! You can now log in.',
        user: {
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
        },
      };
    } catch (error: any) {
      this.logger.error(`❌ Email verification error: ${error.message}`);
      throw error;
    }
  }

  /**
   * 🔐 LOGIN - Authenticate user
   */
  async login(
    identifier: string,
    password: string,
  ): Promise<{ token: string; user: any; subscription: any }> {
    try {
      // ✅ Find user by email or phone
      const user = await this.authModel.findOne({
        $or: [{ email: identifier }, { phoneNumber: identifier }],
      });

      if (!user) {
        throw new HttpException(
          'Invalid email/phone or password',
          HttpStatus.UNAUTHORIZED,
        );
      }

      // ✅ Validate password
      const isValid = await user.validatePassword(password);
      if (!isValid) {
        throw new HttpException(
          'Invalid email/phone or password',
          HttpStatus.UNAUTHORIZED,
        );
      }

      // ✅ Generate JWT token
      const token = this.jwtService.sign({
        sub: (user._id as Types.ObjectId).toString(),
        email: user.email,
      });

      this.logger.log(`✅ User logged in: ${user.email}`);

      // ✅ Get subscription info
      const subscription = await this.getSubscription(user._id as Types.ObjectId);

      return {
        token,
        user: {
          _id: user._id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          phoneNumber: user.phoneNumber,
          emailVerified: user.emailVerified,
        },
        subscription,
      };
    } catch (error: any) {
      this.logger.error(`❌ Login error: ${error.message}`);
      throw error;
    }
  }

  /**
   * 🔑 FORGOT PASSWORD - Request password reset
   */
  async forgotPassword(email: string): Promise<{ message: string }> {
    try {
      // ✅ Find user by email
      const user = await this.authModel.findOne({ email });

      if (!user) {
        this.logger.warn(`⚠️  Password reset requested for non-existent email: ${email}`);
        return {
          message: 'If an account exists with this email, you will receive a password reset link.',
        };
      }

      // ✅ Generate reset token
      const resetToken = this.generateVerificationToken();
      const resetTokenExpiry = new Date(Date.now() + 1 * 60 * 60 * 1000);

      // ✅ Save reset token to user
      user.passwordResetToken = resetToken;
      user.passwordResetTokenExpiry = resetTokenExpiry;
      await user.save();

      this.logger.log(`✅ Password reset token generated for: ${email}`);

      // ✅ Send password reset email
      await this.sendPasswordResetEmail(user.email, user.firstName, resetToken);

      return {
        message: 'Password reset link has been sent to your email.',
      };
    } catch (error: any) {
      this.logger.error(`❌ Forgot password error: ${error.message}`);
      throw new HttpException(
        'Failed to process password reset request',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * 🔐 RESET PASSWORD - Set new password with token
   */
  async resetPassword(
    token: string,
    newPassword: string,
  ): Promise<{ message: string }> {
    try {
      // ✅ Find user with valid reset token
      const user = await this.authModel.findOne({
        passwordResetToken: token,
        passwordResetTokenExpiry: { $gt: new Date() },
      });

      if (!user) {
        throw new HttpException(
          'Invalid or expired reset token',
          HttpStatus.BAD_REQUEST,
        );
      }

      // ✅ Hash new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      // ✅ Update password and clear reset token
      user.password = hashedPassword;
      user.passwordResetToken = undefined;
      user.passwordResetTokenExpiry = undefined;
      await user.save();

      this.logger.log(`✅ Password reset successfully for: ${user.email}`);

      return {
        message: 'Password has been reset successfully. Please log in with your new password.',
      };
    } catch (error: any) {
      this.logger.error(`❌ Password reset error: ${error.message}`);
      throw error;
    }
  }

  /**
   * 👤 Validate user by ID
   */
  async validateUser(userId: Types.ObjectId): Promise<AuthDocument | null> {
    return this.authModel.findById(userId);
  }

  /**
   * 📊 Helper method to get subscription info
   */
  private async getSubscription(userId: Types.ObjectId): Promise<any> {
    // TODO: Implement based on your subscription model/service
    return null;
  }
}