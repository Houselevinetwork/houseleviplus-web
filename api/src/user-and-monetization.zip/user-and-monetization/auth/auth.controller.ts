import {
  Controller,
  Post,
  Body,
  HttpException,
  HttpStatus,
  Logger,
  Get,
  Query,
} from '@nestjs/common';
import { AuthService } from './auth.service';

@Controller('auth')
export class AuthController {
  private readonly logger = new Logger(AuthController.name);

  constructor(private authService: AuthService) {}

  /**
   * 📝 POST /auth/register - Register new user
   */
  @Post('register')
  async register(
    @Body()
    registerDto: {
      firstName: string;
      lastName: string;
      email: string;
      phoneNumber: string;
      password: string;
      confirmPassword: string;
    },
  ) {
    try {
      if (registerDto.password !== registerDto.confirmPassword) {
        throw new HttpException(
          'Passwords do not match',
          HttpStatus.BAD_REQUEST,
        );
      }

      if (registerDto.password.length < 6) {
        throw new HttpException(
          'Password must be at least 6 characters',
          HttpStatus.BAD_REQUEST,
        );
      }

      this.logger.log(`📝 Registration request for: ${registerDto.email}`);
      const result = await this.authService.register(registerDto);

      this.logger.log(`✅ Registration successful for: ${registerDto.email}`);
      return result;
    } catch (error: any) {
      this.logger.error(`❌ Registration error: ${error.message}`);
      throw error;
    }
  }

  /**
   * ✅ GET /auth/verify - Verify email with token (OLD ROUTE - kept for compatibility)
   */
  @Get('verify')
  async verifyEmailOld(@Query('token') token: string) {
    return this.verifyEmail(token);
  }

  /**
   * ✅ GET /auth/verify-email - Verify email with token (NEW ROUTE)
   */
  @Get('verify-email')
  async verifyEmail(@Query('token') token: string) {
    try {
      if (!token) {
        this.logger.error('❌ Verification failed: No token provided');
        throw new HttpException(
          'Verification token is required',
          HttpStatus.BAD_REQUEST,
        );
      }

      this.logger.log(`📧 Email verification request with token: ${token.substring(0, 10)}...`);
      const result = await this.authService.verifyEmail(token);

      this.logger.log(`✅ Email verified successfully for token: ${token.substring(0, 10)}...`);
      return result;
    } catch (error: any) {
      this.logger.error(`❌ Email verification error: ${error.message}`);
      throw error;
    }
  }

  /**
   * 🔐 POST /auth/login - User login
   */
  @Post('login')
  async login(
    @Body()
    loginDto: {
      identifier: string; // email or phone
      password: string;
    },
  ) {
    try {
      if (!loginDto.identifier || !loginDto.password) {
        throw new HttpException(
          'Email/phone and password are required',
          HttpStatus.BAD_REQUEST,
        );
      }

      this.logger.log(`🔐 Login request for: ${loginDto.identifier}`);
      const result = await this.authService.login(
        loginDto.identifier,
        loginDto.password,
      );

      if (!result) {
        throw new HttpException(
          'Invalid credentials',
          HttpStatus.UNAUTHORIZED,
        );
      }

      this.logger.log(`✅ Login successful for: ${loginDto.identifier}`);
      return result;
    } catch (error: any) {
      this.logger.error(`❌ Login error: ${error.message}`);
      throw error;
    }
  }

  /**
   * 🔑 POST /auth/forgot-password - Request password reset
   */
  @Post('forgot-password')
  async forgotPassword(@Body('email') email: string) {
    try {
      if (!email) {
        throw new HttpException(
          'Email is required',
          HttpStatus.BAD_REQUEST,
        );
      }

      this.logger.log(`🔑 Forgot password request for: ${email}`);
      const result = await this.authService.forgotPassword(email);

      this.logger.log(`✅ Password reset email sent`);
      return result;
    } catch (error: any) {
      this.logger.error(`❌ Forgot password error: ${error.message}`);
      throw error;
    }
  }

  /**
   * 🔐 POST /auth/reset-password - Reset password with token
   */
  @Post('reset-password')
  async resetPassword(
    @Body()
    resetDto: {
      token: string;
      newPassword: string;
      confirmPassword: string;
    },
  ) {
    try {
      if (!resetDto.token || !resetDto.newPassword) {
        throw new HttpException(
          'Token and new password are required',
          HttpStatus.BAD_REQUEST,
        );
      }

      if (resetDto.newPassword !== resetDto.confirmPassword) {
        throw new HttpException(
          'Passwords do not match',
          HttpStatus.BAD_REQUEST,
        );
      }

      if (resetDto.newPassword.length < 6) {
        throw new HttpException(
          'Password must be at least 6 characters',
          HttpStatus.BAD_REQUEST,
        );
      }

      this.logger.log(`🔐 Password reset request with token`);
      const result = await this.authService.resetPassword(
        resetDto.token,
        resetDto.newPassword,
      );

      this.logger.log(`✅ Password reset successful`);
      return result;
    } catch (error: any) {
      this.logger.error(`❌ Password reset error: ${error.message}`);
      throw error;
    }
  }
}