import { IsString } from 'class-validator';

export class LoginAuthDto {
  @IsString()
  identifier: string; // email or phone

  @IsString()
  password: string;
}
