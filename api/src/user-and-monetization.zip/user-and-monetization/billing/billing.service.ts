import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { Billing, BillingDocument } from '../schemas/billing.schema';

interface BillingRecord {
  userId: string;
  subscriptionId: string;
  amount: number;
  currency: string;
  transactionType: 'PURCHASE' | 'AUTO_RENEWAL' | 'MANUAL_RENEWAL' | 'REFUND';
  status: 'pending' | 'completed' | 'failed';
  description: string;
  transactionId?: string;
}

@Injectable()
export class BillingService {
  constructor(
    @InjectModel(Billing.name)
    private billingModel: Model<BillingDocument>,
  ) {}

  /**
   * Record a billing transaction
   */
  async recordTransaction(data: BillingRecord) {
    console.log(`💰 Recording billing transaction:`, data);

    try {
      const billing = new this.billingModel({
        userId: new Types.ObjectId(data.userId),
        subscriptionId: new Types.ObjectId(data.subscriptionId),
        amount: data.amount,
        currency: data.currency,
        transactionType: data.transactionType,
        status: data.status,
        description: data.description,
        transactionId: data.transactionId,
        completedAt: data.status === 'completed' ? new Date() : null,
      });

      return await billing.save();
    } catch (error) {
      console.error('❌ Error recording transaction:', error);
      throw error;
    }
  }

  /**
   * Get user's billing history
   */
  async getUserBillingHistory(userId: string, limit: number = 50) {
    console.log(`📊 Fetching billing history for user: ${userId}`);

    try {
      const objectId = new Types.ObjectId(userId);

      return await this.billingModel
        .find({ userId: objectId })
        .sort({ createdAt: -1 })
        .limit(limit)
        .populate('subscriptionId');
    } catch (error) {
      console.error('❌ Error fetching billing history:', error);
      throw error;
    }
  }

  /**
   * Get billing statistics
   */
  async getBillingStats(userId: string) {
    console.log(`📈 Fetching billing stats for user: ${userId}`);

    try {
      const objectId = new Types.ObjectId(userId);

      // Group by status
      const statsByStatus = await this.billingModel.aggregate([
        { $match: { userId: objectId } },
        {
          $group: {
            _id: '$status',
            count: { $sum: 1 },
            total: { $sum: '$amount' },
          },
        },
      ]);

      // Total revenue (completed only)
      const totalRevenue = await this.billingModel.aggregate([
        { $match: { userId: objectId, status: 'completed' } },
        { $group: { _id: null, total: { $sum: '$amount' } } },
      ]);

      return {
        totalRevenue: totalRevenue[0]?.total || 0,
        statsByStatus,
      };
    } catch (error) {
      console.error('❌ Error fetching billing stats:', error);
      throw error;
    }
  }

  /**
   * Get specific invoice
   */
  async getInvoice(userId: string, billingId: string) {
    console.log(`📄 Fetching invoice for user: ${userId}, billing: ${billingId}`);

    try {
      const objectId = new Types.ObjectId(userId);
      const billingObjectId = new Types.ObjectId(billingId);

      const invoice = await this.billingModel
        .findOne({
          _id: billingObjectId,
          userId: objectId,
        })
        .populate('subscriptionId');

      if (!invoice) {
        throw new BadRequestException('Invoice not found');
      }

      return invoice;
    } catch (error) {
      console.error('❌ Error fetching invoice:', error);
      throw error;
    }
  }

  /**
   * Get all invoices for user
   */
  async getUserInvoices(userId: string) {
    console.log(`📄 Fetching all invoices for user: ${userId}`);

    try {
      const objectId = new Types.ObjectId(userId);

      return await this.billingModel
        .find({
          userId: objectId,
          status: 'completed',
        })
        .sort({ createdAt: -1 })
        .populate('subscriptionId');
    } catch (error) {
      console.error('❌ Error fetching invoices:', error);
      throw error;
    }
  }
}
