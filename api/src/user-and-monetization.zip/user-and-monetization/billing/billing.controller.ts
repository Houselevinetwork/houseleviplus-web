import {
  Controller,
  Get,
  Param,
  UseGuards,
  Request,
  BadRequestException,
} from '@nestjs/common';
import { BillingService } from './billing.service';
import { AuthGuard } from '@nestjs/passport';

@Controller('billing')
export class BillingController {
  constructor(private readonly billingService: BillingService) {}

  /**
   * GET /billing/:userId
   * Protected endpoint - Get user's billing data
   * Used by: Frontend useSubscription hook
   */
  @Get(':userId')
  @UseGuards(AuthGuard('jwt'))
  async getUserBilling(
    @Param('userId') userId: string,
    @Request() req: any,
  ) {
    console.log(`📊 GET /billing/${userId} - Get billing data`);

    // Ensure user can only access their own data
    if (req.user.id !== userId) {
      throw new BadRequestException('Cannot access other users billing data');
    }

    try {
      const history = await this.billingService.getUserBillingHistory(userId);
      const stats = await this.billingService.getBillingStats(userId);

      return {
        userId,
        billingHistory: history,
        stats,
      };
    } catch (error) {
      console.error('❌ Error fetching billing data:', error);
      throw new BadRequestException('Failed to fetch billing data');
    }
  }

  /**
   * GET /billing/:userId/invoices
   * Protected endpoint - Get all invoices
   */
  @Get(':userId/invoices')
  @UseGuards(AuthGuard('jwt'))
  async getUserInvoices(
    @Param('userId') userId: string,
    @Request() req: any,
  ) {
    console.log(`📄 GET /billing/${userId}/invoices - Get user invoices`);

    if (req.user.id !== userId) {
      throw new BadRequestException('Cannot access other users invoices');
    }

    return await this.billingService.getUserInvoices(userId);
  }

  /**
   * GET /billing/:userId/invoices/:billingId
   * Protected endpoint - Get specific invoice
   */
  @Get(':userId/invoices/:billingId')
  @UseGuards(AuthGuard('jwt'))
  async getInvoice(
    @Param('userId') userId: string,
    @Param('billingId') billingId: string,
    @Request() req: any,
  ) {
    console.log(
      `📄 GET /billing/${userId}/invoices/${billingId} - Get specific invoice`,
    );

    if (req.user.id !== userId) {
      throw new BadRequestException('Cannot access other users invoices');
    }

    return await this.billingService.getInvoice(userId, billingId);
  }
}

// ============================================
// billing.module.ts
// ============================================
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { BillingService } from './billing.service';
import { BillingController } from './billing.controller';
import { Billing, BillingSchema } from '../schemas/billing.schema';
import { Subscription, SubscriptionSchema } from '../schemas/subscription.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Billing.name, schema: BillingSchema },
      { name: Subscription.name, schema: SubscriptionSchema },
    ]),
  ],
  controllers: [BillingController],
  providers: [BillingService],
  exports: [BillingService],
})
export class BillingModule {}