import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { Cron } from '@nestjs/schedule';
import { Subscription, SubscriptionDocument } from '../schemas/subscription.schema';
import { Billing, BillingDocument } from '../schemas/billing.schema';
import { Payment, PaymentDocument } from '../schemas/payment.schema';

interface SubscriptionPlan {
  id: string;
  planName: string;
  planType: 'monthly' | 'quarterly' | 'half_year' | 'yearly';
  amount: number;
  description: string;
  currency: string;
  durationInMonths: number;
}

interface CreateSubscriptionPayload {
  userId: string;
  planType: 'monthly' | 'quarterly' | 'half_year' | 'yearly';
  planName: string;
  amount: number;
  orderTrackingId?: string;
}

@Injectable()
export class SubscriptionService {
  private readonly SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
    {
      id: 'monthly',
      planName: 'Monthly',
      planType: 'monthly',
      amount: 500,
      description: 'Access to all series and movies, HD quality',
      currency: 'KES',
      durationInMonths: 1,
    },
    {
      id: 'quarterly',
      planName: 'Quarterly',
      planType: 'quarterly',
      amount: 800,
      description: 'Everything in Monthly + 4K Ultra HD quality',
      currency: 'KES',
      durationInMonths: 3,
    },
    {
      id: 'half-year',
      planName: 'Half Year',
      planType: 'half_year',
      amount: 1600,
      description: 'Everything in Quarterly + Early access',
      currency: 'KES',
      durationInMonths: 6,
    },
    {
      id: 'yearly',
      planName: 'Annual',
      planType: 'yearly',
      amount: 3300,
      description: 'Everything + VIP support',
      currency: 'KES',
      durationInMonths: 12,
    },
  ];

  constructor(
    @InjectModel(Subscription.name)
    private subscriptionModel: Model<SubscriptionDocument>,
    @InjectModel(Billing.name)
    private billingModel: Model<BillingDocument>,
    @InjectModel(Payment.name)
    private paymentModel: Model<PaymentDocument>,
  ) {}

  /**
   * Get all available subscription plans
   */
  async getSubscriptions(): Promise<SubscriptionPlan[]> {
    console.log('📋 Fetching subscription plans');
    return this.SUBSCRIPTION_PLANS;
  }

  /**
   * Get user's billing data
   * Used by: Frontend useSubscription hook via GET /billing/:userId
   */
  async getUserBilling(userId: string) {
    console.log(`📊 Fetching billing data for user: ${userId}`);

    try {
      const objectId = new Types.ObjectId(userId);

      // Get current active subscription
      const currentSubscription = await this.subscriptionModel
        .findOne({
          userId: objectId,
          status: 'active',
        })
        .sort({ endDate: -1 });

      // Get subscription history
      const subscriptionHistory = await this.subscriptionModel
        .find({ userId: objectId })
        .sort({ createdAt: -1 })
        .limit(10);

      // Calculate total spent
      const billingAggregation = await this.billingModel.aggregate([
        { $match: { userId: objectId, status: 'completed' } },
        { $group: { _id: null, totalAmount: { $sum: '$amount' } } },
      ]);

      const totalSpent =
        billingAggregation.length > 0 ? billingAggregation[0].totalAmount : 0;

      // Get next renewal date
      let nextRenewalDate = null;
      if (currentSubscription && currentSubscription.autoRenewal) {
        nextRenewalDate = currentSubscription.endDate.toISOString();
      }

      return {
        userId,
        currentSubscription,
        subscriptionHistory,
        totalSpent,
        lastPaymentDate: currentSubscription?.startDate || null,
        nextRenewalDate,
      };
    } catch (error) {
      console.error('❌ Error fetching billing data:', error);
      throw new BadRequestException('Failed to fetch billing data');
    }
  }

  /**
   * Create subscription after payment
   */
  async createSubscription(payload: CreateSubscriptionPayload) {
    console.log(`✅ Creating subscription for user: ${payload.userId}`, payload);

    try {
      const plan = this.SUBSCRIPTION_PLANS.find(
        (p) => p.planType === payload.planType,
      );
      if (!plan) {
        throw new BadRequestException('Invalid plan type');
      }

      const userId = new Types.ObjectId(payload.userId);

      // Calculate end date
      const startDate = new Date();
      const endDate = new Date();
      endDate.setMonth(endDate.getMonth() + plan.durationInMonths);

      // Check if user already has active subscription
      const existingSubscription = await this.subscriptionModel.findOne({
        userId,
        status: 'active',
      });

      if (existingSubscription) {
        console.log(`⏱️  Extending existing subscription for user: ${payload.userId}`);
        return await this.subscriptionModel.findByIdAndUpdate(
          existingSubscription._id,
          {
            endDate,
            autoRenewal: true,
            updatedAt: new Date(),
            orderTrackingId: payload.orderTrackingId,
          },
          { new: true },
        );
      }

      // Create new subscription
      const subscription = new this.subscriptionModel({
        userId,
        planType: payload.planType,
        planName: payload.planName,
        status: 'active',
        amount: payload.amount,
        startDate,
        endDate,
        autoRenewal: true,
        orderTrackingId: payload.orderTrackingId,
      });

      return await subscription.save();
    } catch (error) {
      console.error('❌ Error creating subscription:', error);
      throw error;
    }
  }

  /**
   * Cancel subscription
   */
  async cancelSubscription(userId: string) {
    console.log(`❌ Cancelling subscription for user: ${userId}`);

    try {
      const objectId = new Types.ObjectId(userId);

      const subscription = await this.subscriptionModel.findOne({
        userId: objectId,
        status: 'active',
      });

      if (!subscription) {
        throw new NotFoundException('No active subscription found');
      }

      return await this.subscriptionModel.findByIdAndUpdate(
        subscription._id,
        {
          status: 'cancelled',
          autoRenewal: false,
          updatedAt: new Date(),
        },
        { new: true },
      );
    } catch (error) {
      console.error('❌ Error cancelling subscription:', error);
      throw error;
    }
  }

  /**
   * SCHEDULER: Check for expiring subscriptions and handle auto-renewal
   * Runs daily at 2 AM
   */
  @Cron('0 2 * * *')
  async handleAutoRenewal() {
    console.log('⏰ [SCHEDULER] Starting auto-renewal check...');

    try {
      // Find subscriptions expiring in 3 days
      const expiringDate = new Date();
      expiringDate.setDate(expiringDate.getDate() + 3);

      const expiringSubscriptions = await this.subscriptionModel.find({
        status: 'active',
        autoRenewal: true,
        endDate: {
          $lte: expiringDate,
          $gt: new Date(),
        },
      });

      console.log(
        `⏰ Found ${expiringSubscriptions.length} subscriptions expiring soon`,
      );

      // Send notifications (TODO: integrate email service)
      for (const sub of expiringSubscriptions) {
        console.log(
          `📧 Would send renewal notification for subscription: ${sub._id}`,
        );
        // await this.sendRenewalNotification(user.email, sub.planName);
      }

      // Find subscriptions that have expired
      const expiredSubscriptions = await this.subscriptionModel.find({
        status: 'active',
        autoRenewal: true,
        endDate: { $lte: new Date() },
      });

      console.log(
        `⏰ Found ${expiredSubscriptions.length} subscriptions that expired`,
      );

      // Process auto-renewal for each
      for (const sub of expiredSubscriptions) {
        await this.processAutoRenewal(
          sub.userId.toString(),
          sub.planType,
          sub.planName,
        );
      }
    } catch (error) {
      console.error('❌ Error in auto-renewal scheduler:', error);
    }
  }

  /**
   * Process auto-renewal payment
   */
  private async processAutoRenewal(
    userId: string,
    planType: string,
    planName: string,
  ) {
    console.log(
      `💳 Processing auto-renewal for user: ${userId}, plan: ${planType}`,
    );

    try {
      const plan = this.SUBSCRIPTION_PLANS.find((p) => p.planType === planType);
      if (!plan) {
        throw new Error('Plan not found');
      }

      const objectId = new Types.ObjectId(userId);

      // Calculate new dates
      const startDate = new Date();
      const endDate = new Date();
      endDate.setMonth(endDate.getMonth() + plan.durationInMonths);

      // Update subscription
      const updatedSub = await this.subscriptionModel.findOneAndUpdate(
        { userId: objectId, planType },
        {
          startDate,
          endDate,
          status: 'active',
          updatedAt: new Date(),
        },
        { new: true },
      );

      // Record billing transaction
      const billing = new this.billingModel({
        userId: objectId,
        subscriptionId: updatedSub._id,
        amount: plan.amount,
        currency: plan.currency,
        transactionType: 'AUTO_RENEWAL',
        status: 'completed',
        description: `Auto-renewal: ${planName}`,
        completedAt: new Date(),
      });

      await billing.save();

      console.log(`✅ Auto-renewal successful for user: ${userId}`);
    } catch (error) {
      console.error(`❌ Auto-renewal failed for user: ${userId}`, error);
    }
  }
}