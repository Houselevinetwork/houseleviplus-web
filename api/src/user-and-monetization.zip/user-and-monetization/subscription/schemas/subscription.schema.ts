
// ============================================
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

export type SubscriptionDocument = Subscription & Document;

@Schema({ timestamps: true })
export class Subscription {
  @Prop({ type: Types.ObjectId, ref: 'User', required: true })
  userId: Types.ObjectId;

  @Prop({ required: true, enum: ['monthly', 'quarterly', 'half_year', 'yearly'] })
  planType: string;

  @Prop({ required: true })
  planName: string;

  @Prop({ required: true, type: Number })
  amount: number;

  @Prop({ default: 'KES' })
  currency: string;

  @Prop({ default: 'active', enum: ['active', 'expired', 'cancelled', 'pending'] })
  status: string;

  @Prop({ default: () => new Date() })
  startDate: Date;

  @Prop({ required: true })
  endDate: Date;

  @Prop({ default: true })
  autoRenewal: boolean;

  @Prop()
  transactionId?: string;

  @Prop()
  orderTrackingId?: string;

  @Prop({ type: Object, default: {} })
  metadata?: Record<string, any>;
}

export const SubscriptionSchema = SchemaFactory.createForClass(Subscription);
SubscriptionSchema.index({ userId: 1 });
SubscriptionSchema.index({ status: 1 });
SubscriptionSchema.index({ endDate: 1 });

// ============================================
// schemas/billing.schema.ts
// ============================================
@Schema({ timestamps: true })
export class Billing {
  @Prop({ type: Types.ObjectId, ref: 'User', required: true })
  userId: Types.ObjectId;

  @Prop({ type: Types.ObjectId, ref: 'Subscription', required: true })
  subscriptionId: Types.ObjectId;

  @Prop({ required: true, type: Number })
  amount: number;

  @Prop({ default: 'KES' })
  currency: string;

  @Prop({
    required: true,
    enum: ['PURCHASE', 'AUTO_RENEWAL', 'MANUAL_RENEWAL', 'REFUND'],
  })
  transactionType: string;

  @Prop({ default: 'pending', enum: ['pending', 'completed', 'failed'] })
  status: string;

  @Prop()
  description?: string;

  @Prop()
  transactionId?: string;

  @Prop()
  invoiceNumber?: string;

  @Prop()
  completedAt?: Date;
}

export type BillingDocument = Billing & Document;
export const BillingSchema = SchemaFactory.createForClass(Billing);
BillingSchema.index({ userId: 1 });
BillingSchema.index({ status: 1 });
BillingSchema.index({ createdAt: 1 });