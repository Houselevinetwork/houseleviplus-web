import {
  Controller,
  Get,
  Post,
  Delete,
  Param,
  Body,
  UseGuards,
  Request,
  BadRequestException,
  HttpCode,
} from '@nestjs/common';
import { SubscriptionService } from './subscription.service';
import { AuthGuard } from '@nestjs/passport';

@Controller('subscriptions')
export class SubscriptionController {
  constructor(private readonly subscriptionService: SubscriptionService) {}

  /**
   * GET /subscriptions
   * Public endpoint - Get all subscription plans
   */
  @Get()
  async getAll() {
    console.log('📋 GET /subscriptions - Get all plans');
    return await this.subscriptionService.getSubscriptions();
  }

  /**
   * POST /subscriptions/purchase
   * Protected endpoint - Create subscription after payment
   */
  @Post('purchase')
  @UseGuards(AuthGuard('jwt'))
  @HttpCode(201)
  async purchaseSubscription(
    @Body()
    payload: {
      planType: 'monthly' | 'quarterly' | 'half_year' | 'yearly';
      planName: string;
      amount: number;
      orderTrackingId?: string;
    },
    @Request() req: any,
  ) {
    console.log(`💳 POST /subscriptions/purchase - Purchase subscription`);

    if (!payload.planType || !payload.planName) {
      throw new BadRequestException('Invalid plan data');
    }

    return await this.subscriptionService.createSubscription({
      userId: req.user.id,
      ...payload,
    });
  }

  /**
   * DELETE /subscriptions/cancel
   * Protected endpoint - Cancel subscription
   */
  @Delete('cancel')
  @UseGuards(AuthGuard('jwt'))
  @HttpCode(200)
  async cancelSubscription(@Request() req: any) {
    console.log(`❌ DELETE /subscriptions/cancel - Cancel subscription`);
    return await this.subscriptionService.cancelSubscription(req.user.id);
  }
}

// ============================================
// subscription.module.ts
// ============================================
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ScheduleModule } from '@nestjs/schedule';
import { SubscriptionService } from './subscription.service';
import { SubscriptionController } from './subscription.controller';
import { Subscription, SubscriptionSchema } from '../schemas/subscription.schema';
import { Billing, BillingSchema } from '../schemas/billing.schema';
import { Payment, PaymentSchema } from '../schemas/payment.schema';

@Module({
  imports: [
    ScheduleModule.forRoot(),
    MongooseModule.forFeature([
      { name: Subscription.name, schema: SubscriptionSchema },
      { name: Billing.name, schema: BillingSchema },
      { name: Payment.name, schema: PaymentSchema },
    ]),
  ],
  controllers: [SubscriptionController],
  providers: [SubscriptionService],
  exports: [SubscriptionService],
})
export class SubscriptionModule {}