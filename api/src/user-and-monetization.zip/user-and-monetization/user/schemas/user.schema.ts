﻿import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { Role } from '../../role/schemas/role.schema'; // Correct relative path

export type UserDocument = User & Document;

@Schema({ timestamps: true })
export class User {
  @Prop({ required: true })
  firstName: string;

  @Prop({ required: true })
  lastName: string;

  @Prop({ required: true, unique: true })
  email: string;

  @Prop({ required: true, unique: true })
  phoneNumber: string;

  @Prop({ required: true })
  password: string;

  @Prop({ type: Types.ObjectId, ref: Role.name })
  role: Role;

  // Add other fields like wallet, subscription etc. as needed
}

export const UserSchema = SchemaFactory.createForClass(User);

// Optional: add password validation method here if needed
UserSchema.methods.validatePassword = async function (
  plainPassword: string,
): Promise<boolean> {
  // Example using bcrypt
  const bcrypt = await import('bcrypt');
  return bcrypt.compare(plainPassword, this.password);
};

