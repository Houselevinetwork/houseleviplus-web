import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { User, UserDocument } from './schemas/user.schema';
import { CreateUserDto } from './dto/user.dto';
import { RoleService } from '../role/role.service';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UserService {
  constructor(
    @InjectModel(User.name) private userModel: Model<UserDocument>,
    private readonly roleService: RoleService,
  ) {}

  async createUser(dto: CreateUserDto): Promise<UserDocument> {
    const role = await this.roleService.findByName(dto.roleId);
    const hashedPassword = await bcrypt.hash(dto.password, 10);

    const user = new this.userModel({
      ...dto,
      password: hashedPassword,
      role: role._id,
    });
    return user.save();
  }

  async findByEmail(email: string): Promise<UserDocument> {
    const user = await this.userModel.findOne({ email }).populate('role').populate('wallet');
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  async findById(id: string | Types.ObjectId): Promise<UserDocument> {
    const user = await this.userModel.findById(id).populate('role').populate('wallet');
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  async validatePassword(email: string, password: string): Promise<boolean> {
    const user = await this.userModel.findOne({ email });
    if (!user) return false;
    return bcrypt.compare(password, user.password);
  }
}
