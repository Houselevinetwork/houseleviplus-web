import { IsEmail, IsNotEmpty, IsString } from 'class-validator';

export class CreateUserDto {
  @IsNotEmpty() firstName: string;
  @IsNotEmpty() lastName: string;
  @IsEmail() email: string;
  @IsString() phoneNumber: string;
  @IsString() password: string;
  @IsString() roleId: string; // reference role
}
